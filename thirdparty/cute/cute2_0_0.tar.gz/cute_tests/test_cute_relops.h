#include "cute_suite.h"

extern cute::suite make_suite_test_cute_relops();
